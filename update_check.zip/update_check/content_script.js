chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if(request.message == "update_check"){
		console.log(request.message);
	}
	sendResponse({}); // 送り返すものがない場合は空のオブジェクトを送る
});
