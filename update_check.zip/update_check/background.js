var date_before_str = "";
var date_str = "";

function load(){
	fetch('https://tenki.jp/amedas/1/2/14163.html')
		.then(dataWrappedByPromise => dataWrappedByPromise.text())
		.then(res => {
			var result_match = res.match(/class="date-time">(.*?)現在<\/time>/);
			date_str = result_match[1];

			console.log(date_before_str)
			console.log(date_str)

			if(date_before_str == ""){
				date_before_str = date_str
				chrome.action.setIcon({path:"icon_off.png"});
			} else {
				if(date_before_str != date_str){
					console.log("date_before_str != date_str")
					chrome.action.setIcon({path:"icon_on.png"});
				}
			}

	})
}

console.log("start")

chrome.alarms.onAlarm.addListener(function (alarm) {
	if (alarm.name == "update_check") {
		console.log("alarm.name")
		load();
	}
});
chrome.alarms.create("update_check", { delayInMinutes : 0, periodInMinutes : 1 });

function updateIcon() {
	console.log("updateIcon")
	date_before_str = date_str
	chrome.action.setIcon({path:"icon_off.png"});
}

chrome.action.onClicked.addListener(updateIcon);

